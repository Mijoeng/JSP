package kr.ac.kopo.ui;

public interface ITeblbookUI {

	void execute() throws Exception;
}
