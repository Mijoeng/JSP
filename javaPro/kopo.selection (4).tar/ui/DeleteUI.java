package kr.ac.kopo.ui;

public class DeleteUI extends BaseUI {

	@Override
	public void execute() throws Exception {
		System.out.println("연락처 삭제를 선택하였습니다");
		
	}

}
