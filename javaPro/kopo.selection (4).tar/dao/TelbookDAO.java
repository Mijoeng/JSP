package kr.ac.kopo.dao;

import java.util.List;

import kr.ac.kopo.vo.TelbookVO;

/**
 * 전화번호부에 전화번호를 생성/조회/수정/삭제
 * @author User
 *
 */
public class TelbookDAO {

	private List<TelbookVO> bookList;
}





]
		
		