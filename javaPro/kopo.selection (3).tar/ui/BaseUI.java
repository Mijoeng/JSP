package kr.ac.kopo.ui;

import java.util.Scanner;

import kr.ac.kopo.PhoneBookServiceFactory;
import kr.ac.kopo.service.PhoneBookService;

public abstract class BaseUI implements IPhoneBookUI {

	private Scanner sc = new Scanner(System.in);
	protected PhoneBookService service;
	
	public BaseUI() {
		service = PhoneBookServiceFactory.getInstance();
	}

	/**
	 * 
	 *  String name = scanStr("이름을 입력하세요 : ");
	 * 
	 */
	protected String scanStr(String msg) {
		System.out.print(msg);
		return sc.nextLine();
	}
	
	protected int scanInt(String msg) {
		System.out.print(msg);
		return Integer.parseInt(sc.nextLine());
	}
}





