package kr.ac.kopo.ui;

import kr.ac.kopo.PhoneBookServiceFactory;
import kr.ac.kopo.service.PhoneBookService;
import kr.ac.kopo.vo.PhoneBookVO;

public class AddUI extends BaseUI {
	
	@Override
	public void execute() throws Exception {
		
		String name = scanStr("등록할 이름을 입력하세요 : ");
		String phone = scanStr("등록할 전화번호를 입력하세요 : ");
		
		PhoneBookVO phoneVO = new PhoneBookVO();
		phoneVO.setName(name);
		phoneVO.setPhone(phone);
		
		service.addPhoneBook(phoneVO);
		
		System.out.println("전화번호에 저장이 완료되었습니다");
		
	}

}
