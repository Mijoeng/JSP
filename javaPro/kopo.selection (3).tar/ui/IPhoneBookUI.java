package kr.ac.kopo.ui;

public interface IPhoneBookUI {

	void execute() throws Exception;
}
