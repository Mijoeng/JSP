package kr.ac.kopo.ui;

public class SearchUI extends BaseUI  {

	public void execute() throws Exception {
		
		System.out.println("--------------------------------------------------");
		System.out.println("번호\t글쓴이\t등록일\t제목");
		System.out.println("--------------------------------------------------");
		
		System.out.println("--------------------------------------------------");
	}
}
