package kr.ac.kopo.ui;

public class AddUI extends BaseUI {
	
	public void execute() throws Exception {
		String title  = scanStr("제목을 입력하세요 : ");
		String writer = scanStr("글쓴이를 입력하세요 : ");
		

	}
}
