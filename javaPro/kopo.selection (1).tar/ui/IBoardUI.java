package kr.ac.kopo.ui;

public interface IBoardUI {
	public void execute() throws Exception;
}
