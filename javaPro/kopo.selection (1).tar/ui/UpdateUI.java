package kr.ac.kopo.ui;

public class UpdateUI extends BaseUI {
	
	public void execute() throws Exception {
		int no = scanInt("수정할 글번호를 입력하세요 : ");
		String title  = scanStr("변경할 제목을 입력하세요 : ");
		
	}
}
